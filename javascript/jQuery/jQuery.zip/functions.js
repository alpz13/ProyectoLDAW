$(document).ready(function() {
    alert("hola");
    $("#Eliminar").click(function() {
        confirmar = confirm("Estás seguro de eliminar este usuario?");
        if(confirmar) {
            $.post("<?php echo base_url(); ?>index.php/usuarios_Controller/eliminar", 
            function(data) {
                    $("#resultadoEliminar").html(data);
                });
        }
    });
});