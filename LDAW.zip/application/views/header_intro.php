<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
	<!--<script type="text/javascript" src="<?php echo base_url(); ?>javascript/nbw-parallax.js"></script>-->
	<script type="text/javascript" src="<?php echo base_url(); ?>javascript/jquery.localscroll-1.2.7-min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>javascript/jquery.scrollTo-1.4.2-min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>javascript/jquery.inview.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>javascript/indexJavaScript.js"></script>
        <link type="image/x-icon" href="images/websiteico.ico" rel="shortcut icon"/>
	<script type="text/javascript">
		$(document).ready(function(){
                    $('#nav').localScroll();
		});
	</script>
</head>