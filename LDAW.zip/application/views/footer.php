

<!-- Version anterior
<footer>
    <div>
        Copyright 2014 &COPY; &REG;
        <br/>
        Todos los derechos reservados
    </div>
</footer>

-->
    
				</p>
				<div><br/><br/><br/></div>
            
          
            </div>
          </div>
          <div class="cleaner"></div>
        </div>
      </div>
      <div id="Bottom">
         <p class="down">Copyright &copy; 2014, Design by: Job Scope Team</a></p>
      </div>
    </div>
  </div>
</div>
</body>
</html>
